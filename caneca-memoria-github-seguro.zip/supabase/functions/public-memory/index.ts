import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "GET") return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  const slug = (new URL(req.url).searchParams.get("slug") || "").trim().toUpperCase();
  if (!/^[A-Z0-9-]{8,64}$/.test(slug)) return new Response(JSON.stringify({ error: "Invalid slug" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: memory, error } = await supabase.from("memories").select("id, slug, title, recipient, sender, message, media_type, media_path, cover_path, theme, updated_at").eq("slug", slug).eq("is_active", true).maybeSingle();
  if (error) return new Response(JSON.stringify({ error: "Could not load memory" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  if (!memory) return new Response(JSON.stringify({ error: "Memory not found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  const resolveMedia = async (path: string | null) => {
    if (!path) return null;
    if (/^https?:\/\//i.test(path)) return path;
    const { data } = await supabase.storage.from("memories").createSignedUrl(path, 3600);
    return data?.signedUrl || null;
  };
  const [mediaUrl, coverUrl] = await Promise.all([resolveMedia(memory.media_path), resolveMedia(memory.cover_path)]);
  await supabase.from("memory_scans").insert({ memory_id: memory.id });
  return new Response(JSON.stringify({ slug: memory.slug, title: memory.title, recipient: memory.recipient, sender: memory.sender, message: memory.message, mediaType: memory.media_type, mediaUrl, coverUrl, theme: memory.theme, updatedAt: memory.updated_at }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json", "Cache-Control": "no-store" } });
});
