create extension if not exists pgcrypto;

create table if not exists public.memories (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  slug text unique not null,
  title text not null,
  recipient text,
  sender text,
  message text not null,
  media_type text not null check (media_type in ('image','video','audio')),
  media_path text,
  cover_path text,
  theme text not null default 'amor' check (theme in ('amor','familia','pet','aniversario','homenagem')),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.memory_scans (
  id bigint generated always as identity primary key,
  memory_id uuid not null references public.memories(id) on delete cascade,
  scanned_at timestamptz not null default now()
);

alter table public.memories enable row level security;
alter table public.memory_scans enable row level security;

grant select, insert, update, delete on public.memories to authenticated;
grant select on public.memory_scans to authenticated;

create policy "owners_select_memories" on public.memories for select to authenticated using ((select auth.uid()) = owner_id);
create policy "owners_insert_memories" on public.memories for insert to authenticated with check ((select auth.uid()) = owner_id);
create policy "owners_update_memories" on public.memories for update to authenticated using ((select auth.uid()) = owner_id) with check ((select auth.uid()) = owner_id);
create policy "owners_delete_memories" on public.memories for delete to authenticated using ((select auth.uid()) = owner_id);
create policy "owners_read_scans" on public.memory_scans for select to authenticated using (exists (select 1 from public.memories m where m.id = memory_scans.memory_id and m.owner_id = (select auth.uid())));

create or replace function public.touch_updated_at() returns trigger language plpgsql set search_path = public as $$ begin new.updated_at = now(); return new; end; $$;
drop trigger if exists memories_touch_updated_at on public.memories;
create trigger memories_touch_updated_at before update on public.memories for each row execute function public.touch_updated_at();

insert into storage.buckets (id, name, public) values ('memories', 'memories', false) on conflict (id) do update set public = excluded.public;
create policy "memory_files_owner_insert" on storage.objects for insert to authenticated with check (bucket_id = 'memories' and (storage.foldername(name))[1] = (select auth.uid()::text));
create policy "memory_files_owner_select" on storage.objects for select to authenticated using (bucket_id = 'memories' and (storage.foldername(name))[1] = (select auth.uid()::text));
create policy "memory_files_owner_update" on storage.objects for update to authenticated using (bucket_id = 'memories' and (storage.foldername(name))[1] = (select auth.uid()::text)) with check (bucket_id = 'memories' and (storage.foldername(name))[1] = (select auth.uid()::text));
create policy "memory_files_owner_delete" on storage.objects for delete to authenticated using (bucket_id = 'memories' and (storage.foldername(name))[1] = (select auth.uid()::text));

create index if not exists memories_owner_id_idx on public.memories(owner_id);
create index if not exists memory_scans_memory_id_idx on public.memory_scans(memory_id);
