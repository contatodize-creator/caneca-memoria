import { supabase, supabaseUrl } from "./supabase";
import { Memory, MediaType, PublicMemory, Theme } from "./types";

function mapRow(row: any, scans = 0): Memory {
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    recipient: row.recipient,
    sender: row.sender,
    message: row.message,
    mediaType: row.media_type,
    mediaPath: row.media_path,
    coverPath: row.cover_path,
    theme: row.theme,
    active: row.is_active,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    scans,
  };
}

export function makeSlug() {
  return crypto.randomUUID().replaceAll("-", "").slice(0, 16).toUpperCase();
}

export async function requireUser() {
  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) throw new Error("Faça login para continuar.");
  return data.user;
}

export async function listMemories(): Promise<Memory[]> {
  const user = await requireUser();
  const { data, error } = await supabase
    .from("memories")
    .select("id, slug, title, recipient, sender, message, media_type, media_path, cover_path, theme, is_active, created_at, updated_at")
    .eq("owner_id", user.id)
    .order("created_at", { ascending: false });
  if (error) throw error;

  const ids = (data || []).map((x: any) => x.id);
  const counts = new Map<string, number>();
  if (ids.length) {
    const { data: scans, error: scanError } = await supabase
      .from("memory_scans")
      .select("memory_id")
      .in("memory_id", ids);
    if (scanError) throw scanError;
    for (const scan of scans || []) counts.set(scan.memory_id, (counts.get(scan.memory_id) || 0) + 1);
  }

  return (data || []).map((row: any) => mapRow(row, counts.get(row.id) || 0));
}

export async function getOwnedMemory(slug: string): Promise<Memory | null> {
  const user = await requireUser();
  const { data, error } = await supabase
    .from("memories")
    .select("id, slug, title, recipient, sender, message, media_type, media_path, cover_path, theme, is_active, created_at, updated_at")
    .eq("owner_id", user.id)
    .eq("slug", slug)
    .maybeSingle();
  if (error) throw error;
  if (!data) return null;
  const { count } = await supabase
    .from("memory_scans")
    .select("id", { count: "exact", head: true })
    .eq("memory_id", data.id);
  return mapRow(data, count || 0);
}

export async function createMemory(input: {
  title: string;
  recipient: string;
  sender: string;
  message: string;
  mediaType: MediaType;
  theme: Theme;
  mediaFile?: File | null;
  mediaUrl?: string;
}) {
  const user = await requireUser();
  const slug = makeSlug();
  const { data, error } = await supabase
    .from("memories")
    .insert({
      owner_id: user.id,
      slug,
      title: input.title,
      recipient: input.recipient || null,
      sender: input.sender || null,
      message: input.message,
      media_type: input.mediaType,
      theme: input.theme,
      media_path: input.mediaUrl?.trim() || null,
    })
    .select("id, slug")
    .single();
  if (error) throw error;

  if (input.mediaFile) {
    const ext = input.mediaFile.name.split(".").pop()?.toLowerCase() || "bin";
    const safe = input.mediaFile.name.replace(/[^a-zA-Z0-9._-]/g, "-");
    const path = `${user.id}/${data.id}/${Date.now()}-${safe || `arquivo.${ext}`}`;
    const { error: uploadError } = await supabase.storage.from("memories").upload(path, input.mediaFile, {
      cacheControl: "3600",
      upsert: false,
      contentType: input.mediaFile.type || undefined,
    });
    if (uploadError) {
      await supabase.from("memories").delete().eq("id", data.id);
      throw uploadError;
    }
    const { error: updateError } = await supabase.from("memories").update({ media_path: path }).eq("id", data.id);
    if (updateError) throw updateError;
  }

  return data.slug as string;
}

export async function updateMemory(slug: string, input: {
  title: string;
  recipient: string | null;
  sender: string | null;
  message: string;
  mediaType: MediaType;
  theme: Theme;
  mediaUrl?: string | null;
  active: boolean;
}) {
  const user = await requireUser();
  const changes: Record<string, unknown> = {
    title: input.title,
    recipient: input.recipient || null,
    sender: input.sender || null,
    message: input.message,
    media_type: input.mediaType,
    theme: input.theme,
    is_active: input.active,
  };
  if (input.mediaUrl !== undefined) changes.media_path = input.mediaUrl?.trim() || null;

  const { error } = await supabase
    .from("memories")
    .update(changes)
    .eq("owner_id", user.id)
    .eq("slug", slug);
  if (error) throw error;
}

export async function replaceMedia(slug: string, file: File) {
  const user = await requireUser();
  const memory = await getOwnedMemory(slug);
  if (!memory) throw new Error("Memória não encontrada.");

  const oldPath = memory.mediaPath && !/^https?:\/\//i.test(memory.mediaPath) ? memory.mediaPath : null;
  const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "-");
  const path = `${user.id}/${memory.id}/${Date.now()}-${safe}`;
  const { error: uploadError } = await supabase.storage.from("memories").upload(path, file, {
    cacheControl: "3600",
    upsert: false,
    contentType: file.type || undefined,
  });
  if (uploadError) throw uploadError;
  const { error } = await supabase.from("memories").update({ media_path: path }).eq("id", memory.id);
  if (error) {
    await supabase.storage.from("memories").remove([path]);
    throw error;
  }
  if (oldPath) await supabase.storage.from("memories").remove([oldPath]);
}

export async function deleteMemory(slug: string) {
  const memory = await getOwnedMemory(slug);
  if (!memory) return;
  if (memory.mediaPath && !/^https?:\/\//i.test(memory.mediaPath)) {
    await supabase.storage.from("memories").remove([memory.mediaPath]);
  }
  const { error } = await supabase.from("memories").delete().eq("id", memory.id);
  if (error) throw error;
}

export async function fetchPublicMemory(slug: string): Promise<PublicMemory> {
  const response = await fetch(`${supabaseUrl}/functions/v1/public-memory?slug=${encodeURIComponent(slug)}`, {
    method: "GET",
    headers: { apikey: process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY! },
    cache: "no-store",
  });
  const json = await response.json();
  if (!response.ok) throw new Error(json?.error || "Memória não disponível.");
  return json as PublicMemory;
}
